


class UsuarioModel:
    def __init__(self, nome, idade, email,id):
        self.nome = nome
        self.id=id
        self.idade = idade
        self.email = email
